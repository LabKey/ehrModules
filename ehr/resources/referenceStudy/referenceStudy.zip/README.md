EHR Reference Study
-
This is a reference study that can be used when creating a demo EHR server or as a 
starting point when building a new EHR client module. Base EHR reports and data entry
will be designed around the datasets in this reference study. 
- If using for a base EHR demo, this study can be uploaded directly through the file import process. 
- If using as a starting point for a new EHR client module, this can be copied into the new module and customized as needed.